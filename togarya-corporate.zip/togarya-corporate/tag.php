<?php get_header(); ?>
    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">
            <h1> Posts in: <?php echo single_tag_title(); ?></h1>
<?php if ( have_posts() ) : ?>
			<?php

			// Start the loop.
		while ( have_posts() ) : the_post(); 

                get_template_part( 'template-parts/content', 'summary' );

            endwhile;
 endif;
            ?>

        </main><!-- .site-main -->
    </div><!-- .content-area -->
<?php get_footer(); ?>
