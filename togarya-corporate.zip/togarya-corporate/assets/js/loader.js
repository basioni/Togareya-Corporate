 $(window).load(function(){
		         // Loading Elements
		        $(".loading-overlay .load-cube-grid").fadeOut(2000,function(){
		            $(this).parent().fadeOut(1000,function(){
		                $(this).remove();
		            });
		        });
		    });
