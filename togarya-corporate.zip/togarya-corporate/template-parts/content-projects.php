
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
	</header><!-- .entry-header -->
<div>
	<span class="blog-info"><?php the_time('F j, Y g:i a'); ?> | Posted By: <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a> 
| Project Type: <?php echo get_togareya_taxonomies($post->ID, 'type'); ?></span>
</div>
	<div class="entry-thumbnail">
	<?php the_post_thumbnail(); ?>
	</div>
	<div class="entry-content">
		<?php
   				 the_excerpt();

			
			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'togareyacorporate' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'togareyacorporate' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );

			if ( '' !== get_the_author_meta( 'description' ) ) {
				get_template_part( 'template-parts/biography' );
			}
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php edit_post_link(	sprintf(__('Edit', 'togareyacorporate'))); ?> |
		<a href="<?php echo the_permalink(); ?>"> Read More &raquo;</a>
		</br>
		<?php// twentysixteen_entry_meta(); ?>
		
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->
