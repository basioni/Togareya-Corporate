<?php get_header(); ?>
    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">
 <?php
	 if ( is_home() && ! is_front_page() ) : ?>
				<header>
					<h1><?php single_post_title(); ?></h1>
				</header>
			<?php endif; 
       if ( have_posts() ) : 
	while ( have_posts() ) : the_post(); 

			


			// Include the page content template.
			get_template_part( 'template-parts/content', 'summary' );


			// End of the loop.
		endwhile;
 endif;
            ?>

        </main><!-- .site-main -->
    </div><!-- .content-area -->
<?php get_footer(); ?>
