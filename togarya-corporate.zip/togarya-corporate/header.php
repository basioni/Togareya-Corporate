<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>" />
        	<meta name="viewport" content="width=device-width" />
		<title><?php  bloginfo( 'title' ); wp_title(); ?></title>
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
		<?php if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' ); ?>
		 <script src="<?php echo get_template_directory_uri(); ?>/assets/js/jquery-1.12.1.min.js"></script>
		<!-- Bootstrap core JS -->
		<script src="<?php echo get_template_directory_uri(); ?>/assets/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/bootstrap.min.css">
		<script>
		    $(window).load(function(){
		         // Loading Elements
		        $(".loading-overlay .load-cube-grid").fadeOut(2000,function(){
		            $(this).parent().fadeOut(1000,function(){
		                $(this).remove();
		            });
		        });
		    });
		</script>
		<?php	 wp_head(); ?>

	</head>

	<body>
	<!-- Flat Container Main Block-->

		<nav class="navbar" role="navigation">
				<a class="navbar-logo " href="#">
					<?php if ( function_exists( 'the_custom_logo' ) ) the_custom_logo(); ?>
				</a>

				
				<?php if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
 
  				  $count = WC()->cart->cart_contents_count; ?>
				 <a class="cart-contents" href="<?php echo WC()->cart->get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>"><?php 
   				 if ( $count > 0 ) {
     				   ?>
      				  <span class="cart-contents-count"><?php echo esc_html( $count ); ?></span>
      				  <?php    }     }   ?></a>
 	
	<?php wp_nav_menu( array( 'theme_location' => 'header-menu' ) ); ?>
		</nav>
