
		<!-- start of footer section
		================================================== -->
		<div class="container-fluid footer-container" >
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3" id="footer-first-siderbar">
					<?php dynamic_sidebar('first-footer-widget'); ?>
					
				</div>
				<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3" >
					<?php dynamic_sidebar('second-footer-widget'); ?>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" >
					<?php dynamic_sidebar('third-footer-widget'); ?>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 copyrights" >
					All Copyrights reserved by <a href="#" title="Togaria">Togaria Corporate</a> &copy; <?php echo date("Y"); ?> .
				</div>
			</div>
		</div>    
		<!-- end of footer section
		================================================== -->
        <!--Start Loading Section
        ================================================== -->
        <section class="loading-overlay">
            <div class="load-cube-grid">
              <div class="load-cube load-cube1"></div>
              <div class="load-cube load-cube2"></div>
              <div class="load-cube load-cube3"></div>
              <div class="load-cube load-cube4"></div>
              <div class="load-cube load-cube5"></div>
              <div class="load-cube load-cube6"></div>
              <div class="load-cube load-cube7"></div>
              <div class="load-cube load-cube8"></div>
              <div class="load-cube load-cube9"></div>
            </div>
        </section>
    
        <!--End Loading Section
        ================================================== -->
       

</body>
</html>
