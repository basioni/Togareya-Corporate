<?php
class FooterContacts extends WP_Widget {
 
    function __construct() {
 
        parent::__construct(
            'footer-contacts',  // Base ID
            'Togareya Contacts Info'   // Name
        );
 
        add_action( 'widgets_init', function() {
            register_widget( 'FooterContacts' );
        });
 
    }
 
    public $args = array(
        'before_title'  => '<h4 class="text-center">',
        'after_title'   => '</h4>',
        'before_widget' => '<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">',
        'after_widget'  => '</div>'
    );
 
    public function widget( $args, $instance ) {
 
        echo $args['before_widget'];
 
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
 
        echo '<div class="textwidget">';
	echo '<p class="text-center">';
        echo esc_html__( $instance['text'], 'togareyacorporate' );
	echo '</p>';
	 if (! empty($instance['email']))
		{
        	 echo '	<p><span class="glyphicon glyphicon-envelope"></span> '. esc_html__( $instance['email'], 'togareyacorporate' ) .'</p>';
		}
 	if (! empty($instance['phone']))
		{
		echo '<p><span class="glyphicon glyphicon-phone-alt"></span> '. esc_html__( $instance['phone'], 'togareyacorporate' ) .'</p>';
		}
	 	if (! empty($instance['mobile']))
		{
		echo '<p><span class="glyphicon glyphicon-phone"></span> '. esc_html__( $instance['mobile'], 'togareyacorporate' ) .'</p>';
		}
	 	if (! empty($instance['address']))
		{
		echo '<p><span class="glyphicon glyphicon-flag"></span> '. esc_html__( $instance['address'], 'togareyacorporate' ) .'</p>';
		}

 
        echo '</div>';
 
        echo $args['after_widget'];
 
    }
 
    public function form( $instance ) {
 
        $title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'togareyacorporate' );
        $email = ! empty( $instance['email'] ) ? $instance['email'] : esc_html__( '', 'togareyacorporate' );
	$phone = ! empty( $instance['phone'] ) ? $instance['phone'] : esc_html__( '', 'togareyacorporate' );
	$mobile = ! empty( $instance['mobile'] ) ? $instance['mobile'] : esc_html__( '', 'togareyacorporate' );
	$address = ! empty( $instance['address'] ) ? $instance['address'] : esc_html__( '', 'togareyacorporate' );
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'togareyacorporate' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
	<p>
	<label for="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>"><?php esc_attr_e( 'Email:', 'togareyacorporate' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'email' ) ); ?>" type="text" value="<?php echo esc_attr( $email ); ?>">
        </p>
	<p>
	<label for="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>"><?php esc_attr_e( 'Phone:', 'togareyacorporate' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'phone' ) ); ?>" type="text" value="<?php echo esc_attr( $phone ); ?>">
        </p>
	<p>
	<label for="<?php echo esc_attr( $this->get_field_id( 'mobile' ) ); ?>"><?php esc_attr_e( 'Mobile:', 'togareyacorporate' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'mobile' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'mobile' ) ); ?>" type="text" value="<?php echo esc_attr( $mobile ); ?>">
        </p>
        <p>
	<label for="<?php echo esc_attr( $this->get_field_id( 'address' ) ); ?>"><?php esc_attr_e( 'Address:', 'togareyacorporate' ); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'address' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'address' ) ); ?>" type="text" cols="30" rows="10"><?php echo esc_attr( $address ); ?></textarea>
        </p>
        <?php
 
    }
 
    public function update( $new_instance, $old_instance ) {
 
        $instance = array();
 
        $instance['title'] = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['email'] = ( !empty( $new_instance['email'] ) ) ? $new_instance['email'] : '';
        $instance['mobile'] = ( !empty( $new_instance['mobile'] ) ) ? $new_instance['mobile'] : '';
        $instance['phone'] = ( !empty( $new_instance['phone'] ) ) ? $new_instance['phone'] : '';
        $instance['address'] = ( !empty( $new_instance['address'] ) ) ? $new_instance['address'] : '';
 
        return $instance;
    }
 
}
$footer_contacts_widget = new FooterContacts();


?>
