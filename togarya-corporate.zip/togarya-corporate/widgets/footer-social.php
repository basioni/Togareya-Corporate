<?php
class FooterSocial extends WP_Widget {
 
    function __construct() {
 
        parent::__construct(
            'footer-social-links',  // Base ID
            'Togareya Social Links'   // Name
        );
 
        add_action( 'widgets_init', function() {
            register_widget( 'FooterSocial' );
        });
 
    }
 
    public $args = array(
        'before_title'  => '<h4 class="text-center">',
        'after_title'   => '</h4>',
        'before_widget' => '<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">',
        'after_widget'  => '</div>'
    );
 
    public function widget( $args, $instance ) {
 
        echo $args['before_widget'];
 
        if ( ! empty( $instance['social-links-title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['social-links-title'] ) . $args['after_title'];
        }
 
        echo '<div class="textwidget">';
	echo '<p class="text-center">';
        echo esc_html__( $instance['text'], 'togareyacorporate' );
	echo '</p>';
	echo '<p class="text-center">';
 
	if (! empty($instance['facebook-link']))
	{
        	echo '<a href="'. esc_html__( $instance['facebook-link'], 'togareyacorporate' ) .'" target="blank" alt="Join Us on Facebook" ><img class="img-responsive social-icons" src="'. get_template_directory_uri() .'/assets/images/footer-facebook.png" alt="Facebook Icon" /></a>';
	}

	if (! empty($instance['twitter-link']))
	{
	echo '<a href="'. esc_html__( $instance['twitter-link'], 'togareyacorporate' ) .'" target="blank" alt="Join Us on Twitter" >
		<img class="img-responsive social-icons" src="'.get_template_directory_uri().'/assets/images/footer-twitter.png" alt="Join Us on Twitter" /></a>';
	}
	if (! empty($instance['instagram-link']))
	{
		echo '<a href="'. esc_html__( $instance['instagram-link'], 'togareyacorporate' ) .'" target="blank" alt="Follow Us on Instagram" >
		<img class="img-responsive social-icons" src="'.get_template_directory_uri().'/assets/images/footer-insta.png" alt="Join Us on Instagram" /></a>';
	}
	if (! empty($instance['youtube-link']))
	{
		echo '<a href="'. esc_html__( $instance['youtube-link'], 'togareyacorporate' ) .'" target="blank" alt="Follow Us on YouTube">
		<img class="img-responsive social-icons" src="'.get_template_directory_uri().'/assets/images/footer-youtube.png" alt="Join Us on YouTube" /></a>';
	}
	if (! empty($instance['pinterest-link']))
	{
		echo '<a href="'. esc_html__( $instance['pinterest-link'], 'togareyacorporate' ) .'" target="blank" alt="Follow Us on Pinterest">
		<img class="img-responsive social-icons" src="'.get_template_directory_uri().'/assets/images/footer-pinterest.png" alt="Join Us on Pinterest" /></a>';
	}
		if (! empty($instance['rss-link']))
	{
		echo '<a href="'. esc_html__( $instance['rss-link'], 'togareyacorporate' ) .'" target="blank" alt="Our RSS Feed link">
		<img class="img-responsive social-icons" src="'.get_template_directory_uri().'/assets/images/footer-rss.png" alt="RSS Feed" /></a>';
	}
	echo '</p>';
 
        echo '</div>';
 
        echo $args['after_widget'];
 
    }
 
    public function form( $instance ) {
  $socialstitle = ! empty( $instance['social-links-title'] ) ? $instance['social-links-title'] : esc_html__( '', 'togareyacorporate' );
        $facebook = ! empty( $instance['facebook-link'] ) ? $instance['facebook-link'] : esc_html__( '', 'togareyacorporate' );
	$twitter = ! empty( $instance['twitter-link'] ) ? $instance['twitter-link'] : esc_html__( '', 'togareyacorporate' );
	$instagram = ! empty( $instance['instagram-link'] ) ? $instance['instagram-link'] : esc_html__( '', 'togareyacorporate' );
	$youtube = ! empty( $instance['youtube-link'] ) ? $instance['youtube-link'] : esc_html__( '', 'togareyacorporate' );
	$pinterest = ! empty( $instance['pinterest-link'] ) ? $instance['pinterest-link'] : esc_html__( '', 'togareyacorporate' );
	$rsslink = ! empty( $instance['rss-link'] ) ? $instance['rss-link'] : esc_html__( '', 'togareyacorporate' );
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'social-links-title' ) ); ?>"><?php esc_attr_e( 'Title :', 'togareyacorporate' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'social-links-title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'social-links-title' ) ); ?>" type="text" value="<?php echo esc_attr( $socialstitle ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'facebook-link' ) ); ?>"><?php esc_attr_e( 'Facebook:', 'togareyacorporate' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'facebook-link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'facebook-link' ) ); ?>" type="text" value="<?php echo esc_attr( $facebook ); ?>">
        </p>
	<p>
	<label for="<?php echo esc_attr( $this->get_field_id( 'twitter-link' ) ); ?>"><?php esc_attr_e( 'Twitter:', 'togareyacorporate' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'twitter-link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'twitter-link' ) ); ?>" type="text" value="<?php echo esc_attr( $twitter ); ?>">
        </p>
	<p>
	<label for="<?php echo esc_attr( $this->get_field_id( 'instagram-link' ) ); ?>"><?php esc_attr_e( 'Instagram:', 'togareyacorporate' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'instagram-link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'instagram-link' ) ); ?>" type="text" value="<?php echo esc_attr( $instagram ); ?>">
        </p>
	<p>
	<label for="<?php echo esc_attr( $this->get_field_id( 'youtube-link' ) ); ?>"><?php esc_attr_e( 'YouTube:', 'togareyacorporate' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'youtube-link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'youtube-link' ) ); ?>" type="text" value="<?php echo esc_attr( $youtube ); ?>">
        </p>
        <p>
	<label for="<?php echo esc_attr( $this->get_field_id( 'pinterest-link' ) ); ?>"><?php esc_attr_e( 'Pinterest:', 'togareyacorporate' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'pinterest-link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'pinterest-link' ) ); ?>" type="text" value="<?php echo esc_attr( $pinterest ); ?>">
        </p>
	<p>
	<label for="<?php echo esc_attr( $this->get_field_id( 'rss-link' ) ); ?>"><?php esc_attr_e( 'RSS:', 'togareyacorporate' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'rss-link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'rss-link' ) ); ?>" type="text" value="<?php echo esc_attr( $rsslink ); ?>">
        </p>
        <?php
 
    }
 
    public function update( $new_instance, $old_instance ) {
 
        $instance = array();
 
        $instance['social-links-title'] = ( !empty( $new_instance['social-links-title'] ) ) ? strip_tags( $new_instance['social-links-title'] ) : '';
        $instance['facebook-link'] = ( !empty( $new_instance['facebook-link'] ) ) ? $new_instance['facebook-link'] : '';
        $instance['twitter-link'] = ( !empty( $new_instance['twitter-link'] ) ) ? $new_instance['twitter-link'] : '';
        $instance['instagram-link'] = ( !empty( $new_instance['instagram-link'] ) ) ? $new_instance['instagram-link'] : '';
        $instance['youtube-link'] = ( !empty( $new_instance['youtube-link'] ) ) ? $new_instance['youtube-link'] : '';
	$instance['pinterest-link'] = ( !empty( $new_instance['pinterest-link'] ) ) ? $new_instance['pinterest-link'] : '';
 	$instance['rss-link'] = ( !empty( $new_instance['rss-link'] ) ) ? $new_instance['rss-link'] : '';
 
        return $instance;
    }
 
}
$footer_social_widget = new FooterSocial();


?>
