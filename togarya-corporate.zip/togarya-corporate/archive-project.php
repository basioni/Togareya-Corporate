<?php get_header(); ?>
    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">
		<?php
			the_archive_title( '<h1 class="main-title">', '</h1>' );
			the_archive_description( '<div class="taxonomy-description">', '</div>' );
		?>
			<?php if ( have_posts() ) : 

			// Start the loop.
			while ( have_posts() ) : the_post(); 
			// Include the Projects List template.
			get_template_part( 'template-parts/content', 'projects' );

            endwhile;

            echo the_posts_pagination( array(
			    'prev_text' => __( 'Prev', 'togareyacorporate' ),
			    'next_text' => __( 'Next', 'togareyacorporate' ),
				)
            ); 
 endif; ?>

        </main><!-- .site-main -->
    </div><!-- .content-area -->
<?php get_footer(); ?>
