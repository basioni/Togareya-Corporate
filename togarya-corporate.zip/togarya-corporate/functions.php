<?php

//Load the theme CSS
function theme_add_bootstrap() {
wp_enqueue_style( 'bootstrap-css', get_template_directory_uri() . '/assets/css/bootstrap.min.css' );
wp_enqueue_script( 'bootstrap-js', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array(), '3.3.6', true );
wp_enqueue_style( 'theme-stylesheet', get_stylesheet_uri(), false );
}

add_action( 'wp_enqueue_scripts', 'theme_add_bootstrap' );


// Add Custom logo feature to theme
function theme_logo_setup() {

add_theme_support( 'custom-logo', array(
'height'      => 100,
'width'       => 400,
'flex-width' => true,
'header-text' => array( 'site-title', 'site-description' ),
) );
}
add_action( 'after_setup_theme', 'theme_logo_setup' );

// add featured image feature to theme.
add_theme_support( 'post-thumbnails' );

// Load theme text domain.
load_theme_textdomain( 'togareyacorporate' );

// Register Main Menu
function register_tgr_menu() {
    register_nav_menu('header-menu',__( 'Header Menu' ));
}
add_action( 'init', 'register_tgr_menu' );

/*
* Disable Admin Bar
 **/ 
add_filter( 'show_admin_bar', '__return_false' );

/*
* Register Theme footer Sidebar Widgets
*/ 
function register_tgr_widgets(){
    register_sidebar(array(
        'name' => __("First Footer Widget"),
        'id' => 'first-footer-widget',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '',
        'after_widget'  => '',
        'before_title'  => '<h4 class="text-center">',
        'after_title'   => '</h4>',
    ));
   // Register 1st footer Widget
    register_sidebar(array(
        'name' => __("Second Footer Widget"),
        'id' => 'second-footer-widget',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="text-center">',
        'after_title'   => '</h4>',
    ));
   // Register 2nd footer Widget
    register_sidebar(array(
        'name' => __("Third Footer Widget"),
        'id' => 'third-footer-widget',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="text-center">',
        'after_title'   => '</h4>',
    ));

/**
 * Load the theme front-end widgets.
 */
require_once(get_template_directory()."/widgets/footer-social.php");
require_once(get_template_directory()."/widgets/footer-contacts.php");



}
add_action( 'widgets_init', 'register_tgr_widgets' );

/** Registering front widgets **/ 
add_action( 'widgets_init', function() { register_widget( 'FooterSocial' ); } );
add_action( 'widgets_init', function() { register_widget( 'FooterContacts' ); } );

// Add WooCommerce front end support
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

add_action('woocommerce_before_main_content', 'tgr_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'tgr_theme_wrapper_end', 10);

function tgr_theme_wrapper_start() {
  echo '<section id="main">';
}

function my_theme_wrapper_end() {
  echo '</section>';
}

/*  
 * Togareya Post Categories functions
*/ 
function get_togareya_categories() 
{
	$categories_arr = get_the_category(); 
	$categories = '' ;
	if($categories_arr)
	{
		foreach($categories_arr as $category)
			{
			$categories .= '<a href="'. get_category_link($category->term_id) .'">'. $category->cat_name ."</a>, ";
			}
	}
	return trim($categories, ', ') ;
}

/*  
 * Project Taxonomies functions
*/ 
function get_togareya_taxonomies($postID, $taxonomy) 
{
	$terms_arr = wp_get_post_terms($postID,$taxonomy); 
	$terms = '' ;
	if($terms_arr)
	{
		foreach($terms_arr as $term)
			{
			$terms .= '<a href="'. get_term_link($term->term_id) .'">'. $term->name ."</a>, ";
			}
	}
	return trim($terms, ', ') ;
}

/*  
 * Add Woodommerce Support 
*/ 
add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

/*
* Ensure cart contents update when products are added to the cart via AJAX 
*/ 
function my_header_add_to_cart_fragment( $fragments ) {
 
    ob_start();
    $count = WC()->cart->cart_contents_count;
    ?><a class="cart-contents" href="<?php echo WC()->cart->get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>"><?php
    if ( $count > 0 ) {
        ?>
        <span class="cart-contents-count"><?php echo esc_html( $count ); ?></span>
        <?php            
    }
        ?></a><?php
 
    $fragments['a.cart-contents'] = ob_get_clean();
     
    return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'my_header_add_to_cart_fragment' );


/** TGM Setup **/

require_once(get_template_directory()."/inc/class-tgm-plugin-activation.php");

/** TGM Plugins Activation **/

require_once(get_template_directory()."/inc/tgrpa.php");

?>
